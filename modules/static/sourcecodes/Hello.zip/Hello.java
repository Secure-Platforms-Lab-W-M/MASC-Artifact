package input.placementtest.src;

public class placementcheckertestinput {


    public placementcheckertestinput() {

    }

    public void printA() {
        System.out.println();
    }

    public void printB() {
        System.out.println();

    }


}