package me.kuehle.carreport.util.webdav;

import javax.net.ssl.HostnameVerifier;

public abstract class BadHostnameVerifier3 implements HostnameVerifier {
}
