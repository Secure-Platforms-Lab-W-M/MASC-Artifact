package me.kuehle.carreport.util.webdav;

import javax.net.ssl.HostnameVerifier;

public abstract class BadHostnameVerifier2 implements HostnameVerifier {
}
