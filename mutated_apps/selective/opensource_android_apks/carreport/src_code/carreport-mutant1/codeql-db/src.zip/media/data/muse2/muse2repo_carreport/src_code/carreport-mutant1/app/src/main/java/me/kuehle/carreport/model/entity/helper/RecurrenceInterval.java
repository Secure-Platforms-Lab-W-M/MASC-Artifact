package me.kuehle.carreport.model.entity.helper;

public enum RecurrenceInterval {
    ONCE,
    DAY,
    MONTH,
    QUARTER,
    YEAR
}
