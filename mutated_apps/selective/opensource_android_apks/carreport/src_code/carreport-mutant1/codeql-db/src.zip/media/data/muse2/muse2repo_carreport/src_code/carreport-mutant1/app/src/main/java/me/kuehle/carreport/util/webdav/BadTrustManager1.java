package me.kuehle.carreport.util.webdav;

import javax.net.ssl.X509TrustManager;

public abstract class BadTrustManager1 implements X509TrustManager {
}

