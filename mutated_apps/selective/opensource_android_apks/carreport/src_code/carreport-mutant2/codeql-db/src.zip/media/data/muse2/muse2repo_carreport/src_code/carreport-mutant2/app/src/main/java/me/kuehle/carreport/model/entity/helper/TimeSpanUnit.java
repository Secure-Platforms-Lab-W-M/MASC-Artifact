package me.kuehle.carreport.model.entity.helper;

public enum TimeSpanUnit {
    DAY,
    MONTH,
    YEAR
}
